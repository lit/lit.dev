import { css } from 'lit';
const style = css `
.playground-theme-elegant {
  --playground-code-atom-color: rgb(119, 102, 34);
  --playground-code-builtin-color: rgb(51, 0, 170);
  --playground-code-comment-color: rgb(34, 102, 34);
  --playground-code-keyword-color: rgb(119, 51, 0);
  --playground-code-meta-color: rgb(85, 85, 85);
  --playground-code-number-color: rgb(119, 102, 34);
  --playground-code-qualifier-color: rgb(85, 85, 85);
  --playground-code-string-color: rgb(119, 102, 34);
  --playground-code-variable-2-color: rgb(187, 17, 17)
}
`;
export default style;
