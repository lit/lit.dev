import { css } from 'lit';
const style = css `
.playground-theme-ttcn {
  --playground-code-atom-color: rgb(34, 17, 153);
  --playground-code-attribute-color: rgb(0, 0, 204);
  --playground-code-comment-color: rgb(51, 51, 51);
  --playground-code-def-color: rgb(0, 0, 255);
  --playground-code-meta-color: rgb(85, 85, 85);
  --playground-code-qualifier-color: rgb(85, 85, 85);
  --playground-code-string-color: rgb(0, 100, 0);
  --playground-code-string-2-color: rgb(255, 85, 0);
  --playground-code-tag-color: rgb(17, 119, 0);
  --playground-code-type-color: rgb(0, 136, 85);
  --playground-code-variable-color: rgb(139, 34, 82);
  --playground-code-variable-2-color: rgb(0, 85, 170);
  --playground-code-variable-3-color: rgb(0, 136, 85)
}
`;
export default style;
